const { v4: uuidv4 } = require("uuid")

// Helper functions
const generateId = () => uuidv4()

const daysAgo = (days) => {
  const date = new Date()
  date.setDate(date.getDate() - days)
  return date
}

const daysFromNow = (days) => {
  const date = new Date()
  date.setDate(date.getDate() + days)
  return date
}

const hoursAgo = (hours) => {
  const date = new Date()
  date.setHours(date.getHours() - hours)
  return date
}

// Current user
const CURRENT_USER = {
  id: "user_1",
  name: "John Doe",
  email: "john.doe@example.com",
  role: "student",
  avatar: "/placeholder.svg?height=40&width=40",
  bio: "Computer Science student passionate about AI and machine learning.",
  institution: "MIT",
  createdAt: new Date("2023-01-15"),
  updatedAt: new Date("2023-05-20"),
}

// Mock students
const STUDENTS = [
  {
    id: "user_2",
    name: "Alice Smith",
    email: "alice.smith@example.com",
    role: "student",
    avatar: "/placeholder.svg?height=40&width=40",
    bio: "Physics major with interest in quantum mechanics.",
    institution: "Stanford University",
    createdAt: daysAgo(120),
    updatedAt: daysAgo(30),
  },
  {
    id: "user_3",
    name: "Bob Johnson",
    email: "bob.johnson@example.com",
    role: "student",
    avatar: "/placeholder.svg?height=40&width=40",
    bio: "Chemistry student researching organic compounds.",
    institution: "Harvard University",
    createdAt: daysAgo(100),
    updatedAt: daysAgo(25),
  },
  {
    id: "user_4",
    name: "Carol Williams",
    email: "carol.williams@example.com",
    role: "student",
    avatar: "/placeholder.svg?height=40&width=40",
    bio: "Mathematics enthusiast focusing on abstract algebra.",
    institution: "Caltech",
    createdAt: daysAgo(90),
    updatedAt: daysAgo(20),
  },
]

// Mock teachers
const TEACHERS = [
  {
    id: "user_5",
    name: "Dr. David Brown",
    email: "david.brown@example.com",
    role: "teacher",
    avatar: "/placeholder.svg?height=40&width=40",
    bio: "Professor of Computer Science with 15 years of experience.",
    institution: "MIT",
    createdAt: daysAgo(200),
    updatedAt: daysAgo(50),
  },
  {
    id: "user_6",
    name: "Prof. Emily Davis",
    email: "emily.davis@example.com",
    role: "teacher",
    avatar: "/placeholder.svg?height=40&width=40",
    bio: "Physics researcher specializing in particle physics.",
    institution: "Stanford University",
    createdAt: daysAgo(180),
    updatedAt: daysAgo(45),
  },
]

// All users combined
const USERS = [CURRENT_USER, ...STUDENTS, ...TEACHERS]

// Mock questions
const QUESTIONS = [
  {
    id: generateId(),
    title: "Understanding Calculus Integration Techniques",
    body: "I'm struggling with integration by parts. Can someone explain when to use it versus substitution methods? I've tried working through some examples but I'm still confused about which technique to apply in different scenarios.",
    authorId: STUDENTS[0].id,
    author: STUDENTS[0],
    tags: ["Mathematics", "Calculus", "Integration"],
    views: 124,
    isResolved: false,
    createdAt: hoursAgo(2),
    updatedAt: hoursAgo(2),
    voteCount: 24,
  },
  {
    id: generateId(),
    title: "Quantum Mechanics Probability Question",
    body: "How do we interpret the probability density function in quantum mechanics? I'm confused about the physical meaning. Is it related to the wave function squared?",
    authorId: STUDENTS[1].id,
    author: STUDENTS[1],
    tags: ["Physics", "Quantum Mechanics", "Probability"],
    views: 89,
    isResolved: false,
    createdAt: hoursAgo(4),
    updatedAt: hoursAgo(4),
    voteCount: 18,
  },
  {
    id: generateId(),
    title: "Recursion vs Iteration Efficiency",
    body: "In what scenarios is recursion more efficient than iteration? I'm trying to optimize an algorithm for tree traversal. Are there specific cases where one approach is clearly better than the other?",
    authorId: STUDENTS[2].id,
    author: STUDENTS[2],
    tags: ["Computer Science", "Algorithms", "Recursion"],
    views: 156,
    isResolved: true,
    createdAt: hoursAgo(6),
    updatedAt: hoursAgo(5),
    voteCount: 32,
  },
]

// Mock answers
const ANSWERS = [
  {
    id: generateId(),
    questionId: QUESTIONS[2].id,
    authorId: STUDENTS[0].id,
    author: STUDENTS[0],
    content:
      "Recursion is typically more efficient for problems that have a recursive structure, like tree traversal. The call stack overhead can be a concern, but for balanced trees, the elegance and clarity of recursive code often outweighs the performance difference.",
    isAccepted: true,
    createdAt: hoursAgo(5.5),
    updatedAt: hoursAgo(5.5),
    voteCount: 15,
  },
  {
    id: generateId(),
    questionId: QUESTIONS[2].id,
    authorId: STUDENTS[1].id,
    author: STUDENTS[1],
    content:
      "I'd add that iteration is generally more efficient in terms of memory usage because it doesn't require additional stack frames. However, some algorithms are much more intuitive when expressed recursively.",
    isAccepted: false,
    createdAt: hoursAgo(5),
    updatedAt: hoursAgo(5),
    voteCount: 8,
  },
]

// Mock tasks
const TASKS = [
  {
    id: "task_1",
    title: "Study Algorithms",
    description: "Review quicksort, mergesort, and heapsort algorithms.",
    dueDate: daysFromNow(2),
    status: "in_progress",
    priority: "high",
    userId: CURRENT_USER.id,
    createdAt: daysAgo(10),
    updatedAt: daysAgo(5),
    tags: ["algorithms", "computer science"],
    subjectArea: "Computer Science",
    estimatedTime: 120,
  },
  {
    id: "task_2",
    title: "Physics Lab Report",
    description: "Complete the lab report on wave interference patterns.",
    dueDate: daysFromNow(5),
    status: "not_started",
    priority: "medium",
    userId: CURRENT_USER.id,
    createdAt: daysAgo(8),
    updatedAt: daysAgo(8),
    tags: ["physics", "lab report"],
    subjectArea: "Physics",
    estimatedTime: 90,
  },
]

// Mock notes groups
const NOTES_GROUPS = [
  {
    id: "group_1",
    name: "Computer Science",
    description: "Notes related to algorithms, data structures, and programming concepts.",
    userId: CURRENT_USER.id,
    createdAt: daysAgo(60),
    updatedAt: daysAgo(30),
  },
  {
    id: "group_2",
    name: "Mathematics",
    description: "Notes on calculus, linear algebra, and discrete mathematics.",
    userId: CURRENT_USER.id,
    createdAt: daysAgo(55),
    updatedAt: daysAgo(25),
  },
]

// Mock notes
const NOTES = [
  {
    id: generateId(),
    authorId: CURRENT_USER.id,
    notesGroupId: NOTES_GROUPS[0].id,
    title: "Data Structures",
    visibility: "private",
    createdAt: daysAgo(30),
    updatedAt: daysAgo(5),
    rating: 4.5,
    ratingCount: 10,
    viewCount: 150,
    likeCount: 25,
    dislikeCount: 2,
    files: [
      {
        id: generateId(),
        name: "Introduction",
        type: "file",
        content: "# Introduction to Data Structures\n\nData structures are fundamental...",
        updatedAt: daysAgo(5),
        size: 1024,
      },
    ],
  },
]

// Mock notifications
const NOTIFICATIONS = [
  {
    id: generateId(),
    type: "answer",
    questionId: QUESTIONS[0].id,
    questionTitle: QUESTIONS[0].title,
    answerId: generateId(),
    actorId: STUDENTS[1].id,
    actorName: STUDENTS[1].name,
    actorAvatar: STUDENTS[1].avatar,
    createdAt: hoursAgo(1),
    isRead: false,
  },
]

module.exports = {
  generateId,
  daysAgo,
  daysFromNow,
  hoursAgo,
  CURRENT_USER,
  STUDENTS,
  TEACHERS,
  USERS,
  QUESTIONS,
  ANSWERS,
  TASKS,
  NOTES_GROUPS,
  NOTES,
  NOTIFICATIONS,
}
