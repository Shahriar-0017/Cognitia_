const { body, param, query, validationResult } = require("express-validator")

// Validation result handler
const handleValidationErrors = (req, res, next) => {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(400).json({
      error: "Validation failed",
      details: errors.array(),
    })
  }
  next()
}

// Common validation rules
const validateEmail = body("email").isEmail().normalizeEmail().withMessage("Please provide a valid email address")

const validatePassword = body("password")
  .isLength({ min: 6 })
  .withMessage("Password must be at least 6 characters long")

const validateUUID = (field) => param(field).isUUID().withMessage(`${field} must be a valid UUID`)

const validatePagination = [
  query("page").optional().isInt({ min: 1 }).withMessage("Page must be a positive integer"),
  query("limit").optional().isInt({ min: 1, max: 100 }).withMessage("Limit must be between 1 and 100"),
]

// Question validation
const validateQuestion = [
  body("title").trim().isLength({ min: 5, max: 200 }).withMessage("Title must be between 5 and 200 characters"),
  body("body")
    .trim()
    .isLength({ min: 10, max: 5000 })
    .withMessage("Question body must be between 10 and 5000 characters"),
  body("tags").isArray({ min: 1, max: 5 }).withMessage("Must provide 1-5 tags"),
  body("tags.*").trim().isLength({ min: 1, max: 50 }).withMessage("Each tag must be between 1 and 50 characters"),
]

// Answer validation
const validateAnswer = [
  body("content")
    .trim()
    .isLength({ min: 10, max: 5000 })
    .withMessage("Answer content must be between 10 and 5000 characters"),
]

// Note validation
const validateNote = [
  body("title").trim().isLength({ min: 1, max: 200 }).withMessage("Title must be between 1 and 200 characters"),
  body("visibility").isIn(["private", "public", "shared"]).withMessage("Visibility must be private, public, or shared"),
  body("notesGroupId").isUUID().withMessage("Notes group ID must be a valid UUID"),
]

// Task validation
const validateTask = [
  body("title").trim().isLength({ min: 1, max: 200 }).withMessage("Title must be between 1 and 200 characters"),
  body("description")
    .optional()
    .trim()
    .isLength({ max: 1000 })
    .withMessage("Description must be less than 1000 characters"),
  body("dueDate").isISO8601().withMessage("Due date must be a valid date"),
  body("priority").isIn(["low", "medium", "high"]).withMessage("Priority must be low, medium, or high"),
  body("subjectArea")
    .isIn(["Mathematics", "Physics", "Computer Science", "Chemistry", "Biology", "Literature", "History"])
    .withMessage("Invalid subject area"),
]

module.exports = {
  handleValidationErrors,
  validateEmail,
  validatePassword,
  validateUUID,
  validatePagination,
  validateQuestion,
  validateAnswer,
  validateNote,
  validateTask,
}
