const express = require("express")
const { body, query } = require("express-validator")
const { handleValidationErrors, validatePagination } = require("../middleware/validation")
const { USERS, generateId } = require("../data/mockData")

const router = express.Router()

// Mock settings data
const USER_SETTINGS = {
  notifications: {
    email: true,
    push: true,
    answers: true,
    comments: true,
    mentions: true,
    contests: false,
  },
  privacy: {
    profileVisibility: "public",
    showEmail: false,
    showActivity: true,
    allowMessages: true,
  },
  appearance: {
    theme: "light",
    language: "en",
    timezone: "UTC",
  },
}

const ACTIVITY_LOG = [
  {
    id: generateId(),
    type: "login",
    description: "Logged in successfully",
    timestamp: new Date(Date.now() - 5 * 60 * 1000),
    ipAddress: "192.168.1.1",
    device: "Chrome on Windows",
    location: "New York, USA",
  },
]

const SUPPORT_TICKETS = []

// Get user settings
router.get("/", (req, res) => {
  try {
    res.json({ settings: USER_SETTINGS })
  } catch (error) {
    console.error("Get settings error:", error)
    res.status(500).json({ error: "Failed to fetch settings" })
  }
})

// Update notification settings
router.patch(
  "/notifications",
  [
    body("email").optional().isBoolean().withMessage("Email must be a boolean"),
    body("push").optional().isBoolean().withMessage("Push must be a boolean"),
    body("answers").optional().isBoolean().withMessage("Answers must be a boolean"),
    body("comments").optional().isBoolean().withMessage("Comments must be a boolean"),
    body("mentions").optional().isBoolean().withMessage("Mentions must be a boolean"),
    body("contests").optional().isBoolean().withMessage("Contests must be a boolean"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const updates = req.body

      USER_SETTINGS.notifications = {
        ...USER_SETTINGS.notifications,
        ...updates,
      }

      res.json({
        message: "Notification settings updated successfully",
        settings: USER_SETTINGS.notifications,
      })
    } catch (error) {
      console.error("Update notification settings error:", error)
      res.status(500).json({ error: "Failed to update notification settings" })
    }
  },
)

// Update privacy settings
router.patch(
  "/privacy",
  [
    body("profileVisibility").optional().isIn(["public", "private"]).withMessage("Invalid profile visibility"),
    body("showEmail").optional().isBoolean().withMessage("Show email must be a boolean"),
    body("showActivity").optional().isBoolean().withMessage("Show activity must be a boolean"),
    body("allowMessages").optional().isBoolean().withMessage("Allow messages must be a boolean"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const updates = req.body

      USER_SETTINGS.privacy = {
        ...USER_SETTINGS.privacy,
        ...updates,
      }

      res.json({
        message: "Privacy settings updated successfully",
        settings: USER_SETTINGS.privacy,
      })
    } catch (error) {
      console.error("Update privacy settings error:", error)
      res.status(500).json({ error: "Failed to update privacy settings" })
    }
  },
)

// Update appearance settings
router.patch(
  "/appearance",
  [
    body("theme").optional().isIn(["light", "dark", "system"]).withMessage("Invalid theme"),
    body("language").optional().isString().withMessage("Language must be a string"),
    body("timezone").optional().isString().withMessage("Timezone must be a string"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const updates = req.body

      USER_SETTINGS.appearance = {
        ...USER_SETTINGS.appearance,
        ...updates,
      }

      res.json({
        message: "Appearance settings updated successfully",
        settings: USER_SETTINGS.appearance,
      })
    } catch (error) {
      console.error("Update appearance settings error:", error)
      res.status(500).json({ error: "Failed to update appearance settings" })
    }
  },
)

// Get activity log
router.get("/activity-log", [...validatePagination, handleValidationErrors], (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query

    // Sort by timestamp (newest first)
    const sortedLog = [...ACTIVITY_LOG].sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp))

    // Pagination
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + Number.parseInt(limit)
    const paginatedLog = sortedLog.slice(startIndex, endIndex)

    res.json({
      activities: paginatedLog,
      pagination: {
        currentPage: Number.parseInt(page),
        totalPages: Math.ceil(sortedLog.length / limit),
        totalItems: sortedLog.length,
        itemsPerPage: Number.parseInt(limit),
      },
    })
  } catch (error) {
    console.error("Get activity log error:", error)
    res.status(500).json({ error: "Failed to fetch activity log" })
  }
})

// Get support tickets
router.get(
  "/support/tickets",
  [
    ...validatePagination,
    query("status").optional().isIn(["all", "open", "in_progress", "resolved", "closed"]).withMessage("Invalid status"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const { page = 1, limit = 10, status = "all" } = req.query

      let filteredTickets = [...SUPPORT_TICKETS]

      // Filter by status
      if (status !== "all") {
        filteredTickets = filteredTickets.filter((t) => t.status === status)
      }

      // Sort by creation date (newest first)
      filteredTickets.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))

      // Pagination
      const startIndex = (page - 1) * limit
      const endIndex = startIndex + Number.parseInt(limit)
      const paginatedTickets = filteredTickets.slice(startIndex, endIndex)

      res.json({
        tickets: paginatedTickets,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(filteredTickets.length / limit),
          totalItems: filteredTickets.length,
          itemsPerPage: Number.parseInt(limit),
        },
      })
    } catch (error) {
      console.error("Get support tickets error:", error)
      res.status(500).json({ error: "Failed to fetch support tickets" })
    }
  },
)

// Create support ticket
router.post(
  "/support/tickets",
  [
    body("subject").trim().isLength({ min: 5, max: 200 }).withMessage("Subject must be between 5 and 200 characters"),
    body("description")
      .trim()
      .isLength({ min: 10, max: 2000 })
      .withMessage("Description must be between 10 and 2000 characters"),
    body("priority").optional().isIn(["low", "medium", "high", "urgent"]).withMessage("Invalid priority"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const { subject, description, priority = "medium" } = req.body

      const newTicket = {
        id: generateId(),
        subject,
        description,
        status: "open",
        priority,
        createdAt: new Date(),
        updatedAt: new Date(),
        userId: req.user.id,
        messages: [
          {
            id: generateId(),
            ticketId: null, // Will be set after ticket creation
            sender: "user",
            content: description,
            timestamp: new Date(),
          },
        ],
      }

      // Set ticket ID for the initial message
      newTicket.messages[0].ticketId = newTicket.id

      SUPPORT_TICKETS.push(newTicket)

      res.status(201).json({
        message: "Support ticket created successfully",
        ticket: newTicket,
      })
    } catch (error) {
      console.error("Create support ticket error:", error)
      res.status(500).json({ error: "Failed to create support ticket" })
    }
  },
)

// Add message to support ticket
router.post(
  "/support/tickets/:ticketId/messages",
  [
    body("content").trim().isLength({ min: 1, max: 2000 }).withMessage("Content must be between 1 and 2000 characters"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const { ticketId } = req.params
      const { content } = req.body

      const ticket = SUPPORT_TICKETS.find((t) => t.id === ticketId && t.userId === req.user.id)
      if (!ticket) {
        return res.status(404).json({ error: "Support ticket not found" })
      }

      const newMessage = {
        id: generateId(),
        ticketId,
        sender: "user",
        content,
        timestamp: new Date(),
      }

      ticket.messages.push(newMessage)
      ticket.updatedAt = new Date()

      // If ticket was resolved, reopen it
      if (ticket.status === "resolved") {
        ticket.status = "in_progress"
      }

      res.status(201).json({
        message: "Message added successfully",
        messageData: newMessage,
      })
    } catch (error) {
      console.error("Add message to support ticket error:", error)
      res.status(500).json({ error: "Failed to add message to support ticket" })
    }
  },
)

module.exports = router
