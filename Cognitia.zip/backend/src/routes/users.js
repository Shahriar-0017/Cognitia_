const express = require("express")
const { param, query } = require("express-validator")
const { authenticateToken, optionalAuth } = require("../middleware/auth")
const { handleValidationErrors, validateUUID, validatePagination } = require("../middleware/validation")
const { USERS } = require("../data/mockData")

const router = express.Router()

// Get all users (public profiles only)
router.get(
  "/",
  [
    ...validatePagination,
    query("search").optional().isString().withMessage("Search must be a string"),
    query("role").optional().isIn(["all", "student", "teacher", "admin"]).withMessage("Invalid role"),
    handleValidationErrors,
  ],
  optionalAuth,
  (req, res) => {
    try {
      const { page = 1, limit = 10, search, role = "all" } = req.query

      let filteredUsers = [...USERS]

      // Filter by role
      if (role !== "all") {
        filteredUsers = filteredUsers.filter((u) => u.role === role)
      }

      // Filter by search term
      if (search) {
        const searchLower = search.toLowerCase()
        filteredUsers = filteredUsers.filter(
          (u) =>
            u.name.toLowerCase().includes(searchLower) ||
            u.email.toLowerCase().includes(searchLower) ||
            (u.bio && u.bio.toLowerCase().includes(searchLower)),
        )
      }

      // Remove sensitive information
      const publicUsers = filteredUsers.map((user) => {
        const { password, ...publicUser } = user
        return publicUser
      })

      // Sort by creation date (newest first)
      publicUsers.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))

      // Pagination
      const startIndex = (page - 1) * limit
      const endIndex = startIndex + Number.parseInt(limit)
      const paginatedUsers = publicUsers.slice(startIndex, endIndex)

      res.json({
        users: paginatedUsers,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(publicUsers.length / limit),
          totalItems: publicUsers.length,
          itemsPerPage: Number.parseInt(limit),
        },
      })
    } catch (error) {
      console.error("Get users error:", error)
      res.status(500).json({ error: "Failed to fetch users" })
    }
  },
)

// Get user by ID
router.get("/:id", [validateUUID("id"), handleValidationErrors], optionalAuth, (req, res) => {
  try {
    const user = USERS.find((u) => u.id === req.params.id)
    if (!user) {
      return res.status(404).json({ error: "User not found" })
    }

    // Remove sensitive information
    const { password, ...publicUser } = user

    res.json({ user: publicUser })
  } catch (error) {
    console.error("Get user error:", error)
    res.status(500).json({ error: "Failed to fetch user" })
  }
})

// Get user statistics
router.get("/:id/stats", [validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const user = USERS.find((u) => u.id === req.params.id)
    if (!user) {
      return res.status(404).json({ error: "User not found" })
    }

    // In a real app, these would be calculated from actual data
    const stats = {
      questionsAsked: Math.floor(Math.random() * 50) + 10,
      questionsAnswered: Math.floor(Math.random() * 100) + 20,
      notesCreated: Math.floor(Math.random() * 30) + 5,
      tasksCompleted: Math.floor(Math.random() * 80) + 15,
      contestsParticipated: Math.floor(Math.random() * 15) + 2,
      reputation: Math.floor(Math.random() * 1000) + 100,
      joinDate: user.createdAt,
      lastActive: user.updatedAt,
    }

    res.json({ stats })
  } catch (error) {
    console.error("Get user stats error:", error)
    res.status(500).json({ error: "Failed to fetch user statistics" })
  }
})

module.exports = router
