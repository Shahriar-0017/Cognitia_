const express = require("express")
const { body, param } = require("express-validator")
const { authenticateToken } = require("../middleware/auth")
const { handleValidationErrors, validateAnswer, validateUUID } = require("../middleware/validation")
const { QUESTIONS, ANSWERS, USERS, generateId } = require("../data/mockData")

const router = express.Router()

// Create new answer
router.post(
  "/",
  [
    authenticateToken,
    body("questionId").isUUID().withMessage("Question ID must be a valid UUID"),
    ...validateAnswer,
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const { questionId, content } = req.body

      // Check if question exists
      const question = QUESTIONS.find((q) => q.id === questionId)
      if (!question) {
        return res.status(404).json({ error: "Question not found" })
      }

      const author = USERS.find((u) => u.id === req.user.id)
      if (!author) {
        return res.status(404).json({ error: "User not found" })
      }

      const newAnswer = {
        id: generateId(),
        questionId,
        authorId: req.user.id,
        author,
        content,
        isAccepted: false,
        createdAt: new Date(),
        updatedAt: new Date(),
        voteCount: 0,
      }

      ANSWERS.push(newAnswer)

      res.status(201).json({
        message: "Answer created successfully",
        answer: newAnswer,
      })
    } catch (error) {
      console.error("Create answer error:", error)
      res.status(500).json({ error: "Failed to create answer" })
    }
  },
)

// Update answer
router.put("/:id", [authenticateToken, validateUUID("id"), ...validateAnswer, handleValidationErrors], (req, res) => {
  try {
    const answerIndex = ANSWERS.findIndex((a) => a.id === req.params.id)
    if (answerIndex === -1) {
      return res.status(404).json({ error: "Answer not found" })
    }

    const answer = ANSWERS[answerIndex]

    // Check if user owns the answer
    if (answer.authorId !== req.user.id) {
      return res.status(403).json({ error: "Not authorized to update this answer" })
    }

    const { content } = req.body

    // Update answer
    ANSWERS[answerIndex] = {
      ...answer,
      content,
      updatedAt: new Date(),
    }

    res.json({
      message: "Answer updated successfully",
      answer: ANSWERS[answerIndex],
    })
  } catch (error) {
    console.error("Update answer error:", error)
    res.status(500).json({ error: "Failed to update answer" })
  }
})

// Delete answer
router.delete("/:id", [authenticateToken, validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const answerIndex = ANSWERS.findIndex((a) => a.id === req.params.id)
    if (answerIndex === -1) {
      return res.status(404).json({ error: "Answer not found" })
    }

    const answer = ANSWERS[answerIndex]

    // Check if user owns the answer or is admin
    if (answer.authorId !== req.user.id && req.user.role !== "admin") {
      return res.status(403).json({ error: "Not authorized to delete this answer" })
    }

    // Remove answer
    ANSWERS.splice(answerIndex, 1)

    res.json({ message: "Answer deleted successfully" })
  } catch (error) {
    console.error("Delete answer error:", error)
    res.status(500).json({ error: "Failed to delete answer" })
  }
})

// Vote on answer
router.post(
  "/:id/vote",
  [
    authenticateToken,
    validateUUID("id"),
    body("voteType").isIn(["up", "down"]).withMessage("Vote type must be up or down"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const answer = ANSWERS.find((a) => a.id === req.params.id)
      if (!answer) {
        return res.status(404).json({ error: "Answer not found" })
      }

      const { voteType } = req.body

      // In a real app, you'd track individual votes in a separate table
      // For demo purposes, we'll just update the vote count
      if (voteType === "up") {
        answer.voteCount += 1
      } else {
        answer.voteCount -= 1
      }

      res.json({
        message: "Vote recorded successfully",
        voteCount: answer.voteCount,
      })
    } catch (error) {
      console.error("Vote answer error:", error)
      res.status(500).json({ error: "Failed to record vote" })
    }
  },
)

// Accept answer
router.patch("/:id/accept", [authenticateToken, validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const answer = ANSWERS.find((a) => a.id === req.params.id)
    if (!answer) {
      return res.status(404).json({ error: "Answer not found" })
    }

    // Check if question exists and user owns it
    const question = QUESTIONS.find((q) => q.id === answer.questionId)
    if (!question) {
      return res.status(404).json({ error: "Question not found" })
    }

    if (question.authorId !== req.user.id) {
      return res.status(403).json({ error: "Only question author can accept answers" })
    }

    // Unaccept all other answers for this question
    ANSWERS.forEach((a) => {
      if (a.questionId === answer.questionId) {
        a.isAccepted = false
      }
    })

    // Accept this answer
    answer.isAccepted = true
    answer.updatedAt = new Date()

    // Mark question as resolved
    question.isResolved = true
    question.updatedAt = new Date()

    res.json({
      message: "Answer accepted successfully",
      answer,
    })
  } catch (error) {
    console.error("Accept answer error:", error)
    res.status(500).json({ error: "Failed to accept answer" })
  }
})

module.exports = router
