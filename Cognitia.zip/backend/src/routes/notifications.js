const express = require("express")
const { param, query } = require("express-validator")
const { handleValidationErrors, validateUUID, validatePagination } = require("../middleware/validation")
const { NOTIFICATIONS, generateId } = require("../data/mockData")

const router = express.Router()

// Get all notifications for authenticated user
router.get(
  "/",
  [
    ...validatePagination,
    query("unreadOnly").optional().isBoolean().withMessage("unreadOnly must be a boolean"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const { page = 1, limit = 10, unreadOnly = false } = req.query

      // In a real app, notifications would be filtered by user ID
      let userNotifications = [...NOTIFICATIONS]

      // Filter by read status
      if (unreadOnly === "true") {
        userNotifications = userNotifications.filter((n) => !n.isRead)
      }

      // Sort by creation date (newest first)
      userNotifications.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))

      // Pagination
      const startIndex = (page - 1) * limit
      const endIndex = startIndex + Number.parseInt(limit)
      const paginatedNotifications = userNotifications.slice(startIndex, endIndex)

      res.json({
        notifications: paginatedNotifications,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(userNotifications.length / limit),
          totalItems: userNotifications.length,
          itemsPerPage: Number.parseInt(limit),
        },
        unreadCount: userNotifications.filter((n) => !n.isRead).length,
      })
    } catch (error) {
      console.error("Get notifications error:", error)
      res.status(500).json({ error: "Failed to fetch notifications" })
    }
  },
)

// Mark notification as read
router.patch("/:id/read", [validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const notification = NOTIFICATIONS.find((n) => n.id === req.params.id)
    if (!notification) {
      return res.status(404).json({ error: "Notification not found" })
    }

    notification.isRead = true

    res.json({
      message: "Notification marked as read",
      notification,
    })
  } catch (error) {
    console.error("Mark notification as read error:", error)
    res.status(500).json({ error: "Failed to mark notification as read" })
  }
})

// Mark all notifications as read
router.patch("/read-all", (req, res) => {
  try {
    // In a real app, filter by user ID
    NOTIFICATIONS.forEach((notification) => {
      notification.isRead = true
    })

    res.json({ message: "All notifications marked as read" })
  } catch (error) {
    console.error("Mark all notifications as read error:", error)
    res.status(500).json({ error: "Failed to mark all notifications as read" })
  }
})

// Delete notification
router.delete("/:id", [validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const notificationIndex = NOTIFICATIONS.findIndex((n) => n.id === req.params.id)
    if (notificationIndex === -1) {
      return res.status(404).json({ error: "Notification not found" })
    }

    // Remove notification
    NOTIFICATIONS.splice(notificationIndex, 1)

    res.json({ message: "Notification deleted successfully" })
  } catch (error) {
    console.error("Delete notification error:", error)
    res.status(500).json({ error: "Failed to delete notification" })
  }
})

// Get notification statistics
router.get("/stats", (req, res) => {
  try {
    // In a real app, filter by user ID
    const userNotifications = NOTIFICATIONS

    const stats = {
      total: userNotifications.length,
      unread: userNotifications.filter((n) => !n.isRead).length,
      byType: {
        answer: userNotifications.filter((n) => n.type === "answer").length,
        comment: userNotifications.filter((n) => n.type === "comment").length,
        acceptance: userNotifications.filter((n) => n.type === "acceptance").length,
        mention: userNotifications.filter((n) => n.type === "mention").length,
      },
    }

    res.json({ stats })
  } catch (error) {
    console.error("Get notification stats error:", error)
    res.status(500).json({ error: "Failed to fetch notification statistics" })
  }
})

module.exports = router
