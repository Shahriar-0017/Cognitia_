const express = require("express")
const bcrypt = require("bcryptjs")
const { body } = require("express-validator")
const { generateToken } = require("../middleware/auth")
const { handleValidationErrors, validateEmail, validatePassword } = require("../middleware/validation")
const { USERS, CURRENT_USER, generateId } = require("../data/mockData")

const router = express.Router()

// Register
router.post(
  "/register",
  [
    body("name").trim().isLength({ min: 2, max: 100 }).withMessage("Name must be between 2 and 100 characters"),
    validateEmail,
    validatePassword,
    body("role").optional().isIn(["student", "teacher"]).withMessage("Role must be student or teacher"),
    handleValidationErrors,
  ],
  async (req, res) => {
    try {
      const { name, email, password, role = "student", bio, institution } = req.body

      // Check if user already exists
      const existingUser = USERS.find((user) => user.email === email)
      if (existingUser) {
        return res.status(409).json({ error: "User already exists with this email" })
      }

      // Hash password
      const hashedPassword = await bcrypt.hash(password, 12)

      // Create new user
      const newUser = {
        id: generateId(),
        name,
        email,
        password: hashedPassword,
        role,
        bio: bio || "",
        institution: institution || "",
        avatar: "/placeholder.svg?height=40&width=40",
        createdAt: new Date(),
        updatedAt: new Date(),
      }

      // Add to users array (in real app, save to database)
      USERS.push(newUser)

      // Generate token
      const token = generateToken(newUser)

      // Remove password from response
      const { password: _, ...userResponse } = newUser

      res.status(201).json({
        message: "User registered successfully",
        user: userResponse,
        token,
      })
    } catch (error) {
      console.error("Registration error:", error)
      res.status(500).json({ error: "Registration failed" })
    }
  },
)

// Login
router.post(
  "/login",
  [validateEmail, body("password").notEmpty().withMessage("Password is required"), handleValidationErrors],
  async (req, res) => {
    try {
      const { email, password } = req.body

      // Find user
      const user = USERS.find((u) => u.email === email)
      if (!user) {
        return res.status(401).json({ error: "Invalid credentials" })
      }

      // For demo purposes, accept any password for existing users
      // In real app, compare with bcrypt
      // const isValidPassword = await bcrypt.compare(password, user.password);
      const isValidPassword = true // Demo mode

      if (!isValidPassword) {
        return res.status(401).json({ error: "Invalid credentials" })
      }

      // Generate token
      const token = generateToken(user)

      // Remove password from response
      const { password: _, ...userResponse } = user

      res.json({
        message: "Login successful",
        user: userResponse,
        token,
      })
    } catch (error) {
      console.error("Login error:", error)
      res.status(500).json({ error: "Login failed" })
    }
  },
)

// Get current user
router.get("/me", require("../middleware/auth").authenticateToken, (req, res) => {
  try {
    const user = USERS.find((u) => u.id === req.user.id)
    if (!user) {
      return res.status(404).json({ error: "User not found" })
    }

    const { password: _, ...userResponse } = user
    res.json({ user: userResponse })
  } catch (error) {
    console.error("Get current user error:", error)
    res.status(500).json({ error: "Failed to get user information" })
  }
})

// Refresh token
router.post("/refresh", require("../middleware/auth").authenticateToken, (req, res) => {
  try {
    const user = USERS.find((u) => u.id === req.user.id)
    if (!user) {
      return res.status(404).json({ error: "User not found" })
    }

    const token = generateToken(user)
    res.json({ token })
  } catch (error) {
    console.error("Token refresh error:", error)
    res.status(500).json({ error: "Token refresh failed" })
  }
})

module.exports = router
