const express = require("express")
const { body, param, query } = require("express-validator")
const { authenticateToken, optionalAuth } = require("../middleware/auth")
const { handleValidationErrors, validateNote, validateUUID, validatePagination } = require("../middleware/validation")
const { NOTES, NOTES_GROUPS, USERS, generateId } = require("../data/mockData")

const router = express.Router()

// Get all notes with pagination and filtering
router.get(
  "/",
  [
    ...validatePagination,
    query("visibility").optional().isIn(["all", "public", "private"]).withMessage("Invalid visibility"),
    query("search").optional().isString().withMessage("Search must be a string"),
    query("authorId").optional().isUUID().withMessage("Author ID must be a valid UUID"),
    handleValidationErrors,
  ],
  optionalAuth,
  (req, res) => {
    try {
      const { page = 1, limit = 10, visibility = "all", search, authorId } = req.query

      let filteredNotes = [...NOTES]

      // Filter by visibility
      if (visibility === "public") {
        filteredNotes = filteredNotes.filter((n) => n.visibility === "public")
      } else if (visibility === "private") {
        // Only show private notes to the owner
        if (req.user) {
          filteredNotes = filteredNotes.filter((n) => n.visibility === "private" && n.authorId === req.user.id)
        } else {
          filteredNotes = []
        }
      } else {
        // Show public notes and user's own private notes
        filteredNotes = filteredNotes.filter(
          (n) => n.visibility === "public" || (req.user && n.authorId === req.user.id),
        )
      }

      // Filter by author
      if (authorId) {
        filteredNotes = filteredNotes.filter((n) => n.authorId === authorId)
      }

      // Filter by search term
      if (search) {
        const searchLower = search.toLowerCase()
        filteredNotes = filteredNotes.filter((n) => n.title.toLowerCase().includes(searchLower))
      }

      // Sort by updated date (newest first)
      filteredNotes.sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))

      // Pagination
      const startIndex = (page - 1) * limit
      const endIndex = startIndex + Number.parseInt(limit)
      const paginatedNotes = filteredNotes.slice(startIndex, endIndex)

      res.json({
        notes: paginatedNotes,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(filteredNotes.length / limit),
          totalItems: filteredNotes.length,
          itemsPerPage: Number.parseInt(limit),
        },
      })
    } catch (error) {
      console.error("Get notes error:", error)
      res.status(500).json({ error: "Failed to fetch notes" })
    }
  },
)

// Get note by ID
router.get("/:id", [validateUUID("id"), handleValidationErrors], optionalAuth, (req, res) => {
  try {
    const note = NOTES.find((n) => n.id === req.params.id)
    if (!note) {
      return res.status(404).json({ error: "Note not found" })
    }

    // Check visibility permissions
    if (note.visibility === "private" && (!req.user || note.authorId !== req.user.id)) {
      return res.status(403).json({ error: "Access denied" })
    }

    // Increment view count
    if (note.viewCount !== undefined) {
      note.viewCount += 1
    }

    res.json({ note })
  } catch (error) {
    console.error("Get note error:", error)
    res.status(500).json({ error: "Failed to fetch note" })
  }
})

// Create new note
router.post("/", [authenticateToken, ...validateNote, handleValidationErrors], (req, res) => {
  try {
    const { title, visibility, notesGroupId, files = [] } = req.body

    // Check if notes group exists and belongs to user
    const notesGroup = NOTES_GROUPS.find((g) => g.id === notesGroupId)
    if (!notesGroup) {
      return res.status(404).json({ error: "Notes group not found" })
    }

    if (notesGroup.userId !== req.user.id) {
      return res.status(403).json({ error: "Not authorized to add notes to this group" })
    }

    const newNote = {
      id: generateId(),
      authorId: req.user.id,
      notesGroupId,
      title,
      visibility,
      createdAt: new Date(),
      updatedAt: new Date(),
      files: files.map((file) => ({
        ...file,
        id: file.id || generateId(),
        updatedAt: new Date(),
      })),
      viewCount: 0,
      likeCount: 0,
      dislikeCount: 0,
      rating: 0,
      ratingCount: 0,
    }

    NOTES.push(newNote)

    res.status(201).json({
      message: "Note created successfully",
      note: newNote,
    })
  } catch (error) {
    console.error("Create note error:", error)
    res.status(500).json({ error: "Failed to create note" })
  }
})

// Update note
router.put("/:id", [authenticateToken, validateUUID("id"), ...validateNote, handleValidationErrors], (req, res) => {
  try {
    const noteIndex = NOTES.findIndex((n) => n.id === req.params.id)
    if (noteIndex === -1) {
      return res.status(404).json({ error: "Note not found" })
    }

    const note = NOTES[noteIndex]

    // Check if user owns the note
    if (note.authorId !== req.user.id) {
      return res.status(403).json({ error: "Not authorized to update this note" })
    }

    const { title, visibility, files } = req.body

    // Update note
    NOTES[noteIndex] = {
      ...note,
      title,
      visibility,
      files: files
        ? files.map((file) => ({
            ...file,
            id: file.id || generateId(),
            updatedAt: new Date(),
          }))
        : note.files,
      updatedAt: new Date(),
    }

    res.json({
      message: "Note updated successfully",
      note: NOTES[noteIndex],
    })
  } catch (error) {
    console.error("Update note error:", error)
    res.status(500).json({ error: "Failed to update note" })
  }
})

// Delete note
router.delete("/:id", [authenticateToken, validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const noteIndex = NOTES.findIndex((n) => n.id === req.params.id)
    if (noteIndex === -1) {
      return res.status(404).json({ error: "Note not found" })
    }

    const note = NOTES[noteIndex]

    // Check if user owns the note or is admin
    if (note.authorId !== req.user.id && req.user.role !== "admin") {
      return res.status(403).json({ error: "Not authorized to delete this note" })
    }

    // Remove note
    NOTES.splice(noteIndex, 1)

    res.json({ message: "Note deleted successfully" })
  } catch (error) {
    console.error("Delete note error:", error)
    res.status(500).json({ error: "Failed to delete note" })
  }
})

// Get notes groups
router.get("/groups/all", [authenticateToken, handleValidationErrors], (req, res) => {
  try {
    const userGroups = NOTES_GROUPS.filter((g) => g.userId === req.user.id)
    res.json({ groups: userGroups })
  } catch (error) {
    console.error("Get notes groups error:", error)
    res.status(500).json({ error: "Failed to fetch notes groups" })
  }
})

// Create notes group
router.post(
  "/groups",
  [
    authenticateToken,
    body("name").trim().isLength({ min: 1, max: 100 }).withMessage("Name must be between 1 and 100 characters"),
    body("description")
      .optional()
      .trim()
      .isLength({ max: 500 })
      .withMessage("Description must be less than 500 characters"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const { name, description } = req.body

      const newGroup = {
        id: generateId(),
        name,
        description: description || "",
        userId: req.user.id,
        createdAt: new Date(),
        updatedAt: new Date(),
      }

      NOTES_GROUPS.push(newGroup)

      res.status(201).json({
        message: "Notes group created successfully",
        group: newGroup,
      })
    } catch (error) {
      console.error("Create notes group error:", error)
      res.status(500).json({ error: "Failed to create notes group" })
    }
  },
)

// Rate note
router.post(
  "/:id/rate",
  [
    authenticateToken,
    validateUUID("id"),
    body("rating").isInt({ min: 1, max: 5 }).withMessage("Rating must be between 1 and 5"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const note = NOTES.find((n) => n.id === req.params.id)
      if (!note) {
        return res.status(404).json({ error: "Note not found" })
      }

      // Check if note is public
      if (note.visibility !== "public") {
        return res.status(403).json({ error: "Can only rate public notes" })
      }

      const { rating } = req.body

      // Update rating (simplified - in real app, track individual ratings)
      const currentTotal = (note.rating || 0) * (note.ratingCount || 0)
      const newRatingCount = (note.ratingCount || 0) + 1
      const newRating = (currentTotal + rating) / newRatingCount

      note.rating = Math.round(newRating * 10) / 10 // Round to 1 decimal place
      note.ratingCount = newRatingCount

      res.json({
        message: "Rating recorded successfully",
        rating: note.rating,
        ratingCount: note.ratingCount,
      })
    } catch (error) {
      console.error("Rate note error:", error)
      res.status(500).json({ error: "Failed to rate note" })
    }
  },
)

module.exports = router
