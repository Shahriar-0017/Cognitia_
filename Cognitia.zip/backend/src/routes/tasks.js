const express = require("express")
const { body, param, query } = require("express-validator")
const { handleValidationErrors, validateTask, validateUUID, validatePagination } = require("../middleware/validation")
const { TASKS, generateId } = require("../data/mockData")

const router = express.Router()

// Get all tasks for authenticated user
router.get(
  "/",
  [
    ...validatePagination,
    query("status").optional().isIn(["all", "not_started", "in_progress", "completed"]).withMessage("Invalid status"),
    query("priority").optional().isIn(["all", "low", "medium", "high"]).withMessage("Invalid priority"),
    query("subjectArea").optional().isString().withMessage("Subject area must be a string"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const { page = 1, limit = 10, status = "all", priority = "all", subjectArea } = req.query

      let userTasks = TASKS.filter((t) => t.userId === req.user.id)

      // Filter by status
      if (status !== "all") {
        userTasks = userTasks.filter((t) => t.status === status)
      }

      // Filter by priority
      if (priority !== "all") {
        userTasks = userTasks.filter((t) => t.priority === priority)
      }

      // Filter by subject area
      if (subjectArea) {
        userTasks = userTasks.filter((t) => t.subjectArea === subjectArea)
      }

      // Sort by due date (nearest first)
      userTasks.sort((a, b) => new Date(a.dueDate) - new Date(b.dueDate))

      // Pagination
      const startIndex = (page - 1) * limit
      const endIndex = startIndex + Number.parseInt(limit)
      const paginatedTasks = userTasks.slice(startIndex, endIndex)

      res.json({
        tasks: paginatedTasks,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(userTasks.length / limit),
          totalItems: userTasks.length,
          itemsPerPage: Number.parseInt(limit),
        },
      })
    } catch (error) {
      console.error("Get tasks error:", error)
      res.status(500).json({ error: "Failed to fetch tasks" })
    }
  },
)

// Get task by ID
router.get("/:id", [validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const task = TASKS.find((t) => t.id === req.params.id && t.userId === req.user.id)
    if (!task) {
      return res.status(404).json({ error: "Task not found" })
    }

    res.json({ task })
  } catch (error) {
    console.error("Get task error:", error)
    res.status(500).json({ error: "Failed to fetch task" })
  }
})

// Create new task
router.post("/", [...validateTask, handleValidationErrors], (req, res) => {
  try {
    const { title, description, dueDate, priority, subjectArea, tags = [], estimatedTime } = req.body

    const newTask = {
      id: generateId(),
      title,
      description: description || "",
      dueDate: new Date(dueDate),
      status: "not_started",
      priority,
      userId: req.user.id,
      createdAt: new Date(),
      updatedAt: new Date(),
      tags,
      subjectArea,
      estimatedTime: estimatedTime || null,
    }

    TASKS.push(newTask)

    res.status(201).json({
      message: "Task created successfully",
      task: newTask,
    })
  } catch (error) {
    console.error("Create task error:", error)
    res.status(500).json({ error: "Failed to create task" })
  }
})

// Update task
router.put("/:id", [validateUUID("id"), ...validateTask, handleValidationErrors], (req, res) => {
  try {
    const taskIndex = TASKS.findIndex((t) => t.id === req.params.id && t.userId === req.user.id)
    if (taskIndex === -1) {
      return res.status(404).json({ error: "Task not found" })
    }

    const { title, description, dueDate, priority, subjectArea, tags, estimatedTime } = req.body

    // Update task
    TASKS[taskIndex] = {
      ...TASKS[taskIndex],
      title,
      description: description || "",
      dueDate: new Date(dueDate),
      priority,
      subjectArea,
      tags: tags || TASKS[taskIndex].tags,
      estimatedTime: estimatedTime !== undefined ? estimatedTime : TASKS[taskIndex].estimatedTime,
      updatedAt: new Date(),
    }

    res.json({
      message: "Task updated successfully",
      task: TASKS[taskIndex],
    })
  } catch (error) {
    console.error("Update task error:", error)
    res.status(500).json({ error: "Failed to update task" })
  }
})

// Update task status
router.patch(
  "/:id/status",
  [
    validateUUID("id"),
    body("status").isIn(["not_started", "in_progress", "completed"]).withMessage("Invalid status"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const task = TASKS.find((t) => t.id === req.params.id && t.userId === req.user.id)
      if (!task) {
        return res.status(404).json({ error: "Task not found" })
      }

      const { status } = req.body

      task.status = status
      task.updatedAt = new Date()

      if (status === "completed") {
        task.completedAt = new Date()
      } else {
        delete task.completedAt
      }

      res.json({
        message: "Task status updated successfully",
        task,
      })
    } catch (error) {
      console.error("Update task status error:", error)
      res.status(500).json({ error: "Failed to update task status" })
    }
  },
)

// Delete task
router.delete("/:id", [validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const taskIndex = TASKS.findIndex((t) => t.id === req.params.id && t.userId === req.user.id)
    if (taskIndex === -1) {
      return res.status(404).json({ error: "Task not found" })
    }

    // Remove task
    TASKS.splice(taskIndex, 1)

    res.json({ message: "Task deleted successfully" })
  } catch (error) {
    console.error("Delete task error:", error)
    res.status(500).json({ error: "Failed to delete task" })
  }
})

// Get task statistics
router.get("/stats/overview", (req, res) => {
  try {
    const userTasks = TASKS.filter((t) => t.userId === req.user.id)

    const stats = {
      total: userTasks.length,
      completed: userTasks.filter((t) => t.status === "completed").length,
      inProgress: userTasks.filter((t) => t.status === "in_progress").length,
      notStarted: userTasks.filter((t) => t.status === "not_started").length,
      overdue: userTasks.filter((t) => t.status !== "completed" && new Date(t.dueDate) < new Date()).length,
      byPriority: {
        high: userTasks.filter((t) => t.priority === "high").length,
        medium: userTasks.filter((t) => t.priority === "medium").length,
        low: userTasks.filter((t) => t.priority === "low").length,
      },
      bySubject: userTasks.reduce((acc, task) => {
        acc[task.subjectArea] = (acc[task.subjectArea] || 0) + 1
        return acc
      }, {}),
    }

    res.json({ stats })
  } catch (error) {
    console.error("Get task stats error:", error)
    res.status(500).json({ error: "Failed to fetch task statistics" })
  }
})

module.exports = router
