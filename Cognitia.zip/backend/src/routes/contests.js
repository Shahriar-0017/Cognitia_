const express = require("express")
const { body, param, query } = require("express-validator")
const { authenticateToken, optionalAuth } = require("../middleware/auth")
const { handleValidationErrors, validateUUID, validatePagination } = require("../middleware/validation")
const { generateId, daysAgo, daysFromNow } = require("../data/mockData")

const router = express.Router()

// Mock contest data
const CONTESTS = [
  {
    id: generateId(),
    title: "Weekly Coding Challenge #1",
    description: "Solve algorithmic problems and compete with other students in this weekly coding challenge.",
    startTime: daysAgo(1),
    endTime: daysFromNow(1),
    status: "ongoing",
    organizer: {
      id: "user_2",
      name: "Alice Smith",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    difficulty: "medium",
    participants: 120,
    topics: ["algorithms", "data-structures"],
    isVirtual: false,
    eligibility: "Open for all",
    createdAt: daysAgo(7),
    updatedAt: daysAgo(1),
  },
  {
    id: generateId(),
    title: "Data Structures Mastery",
    description: "Test your knowledge of data structures with this challenging contest.",
    startTime: daysFromNow(3),
    endTime: daysFromNow(4),
    status: "upcoming",
    organizer: {
      id: "user_3",
      name: "Bob Johnson",
      avatar: "/placeholder.svg?height=40&width=40",
    },
    difficulty: "hard",
    participants: 85,
    topics: ["data-structures", "algorithms"],
    isVirtual: false,
    eligibility: "Open for all",
    createdAt: daysAgo(14),
    updatedAt: daysAgo(3),
  },
]

const CONTEST_REGISTRATIONS = []
const CONTEST_SUBMISSIONS = []

// Get all contests
router.get(
  "/",
  [
    ...validatePagination,
    query("status").optional().isIn(["all", "upcoming", "ongoing", "finished"]).withMessage("Invalid status"),
    query("difficulty").optional().isIn(["all", "easy", "medium", "hard", "expert"]).withMessage("Invalid difficulty"),
    query("search").optional().isString().withMessage("Search must be a string"),
    handleValidationErrors,
  ],
  optionalAuth,
  (req, res) => {
    try {
      const { page = 1, limit = 10, status = "all", difficulty = "all", search } = req.query

      let filteredContests = [...CONTESTS]

      // Filter by status
      if (status !== "all") {
        filteredContests = filteredContests.filter((c) => c.status === status)
      }

      // Filter by difficulty
      if (difficulty !== "all") {
        filteredContests = filteredContests.filter((c) => c.difficulty === difficulty)
      }

      // Filter by search term
      if (search) {
        const searchLower = search.toLowerCase()
        filteredContests = filteredContests.filter(
          (c) => c.title.toLowerCase().includes(searchLower) || c.description.toLowerCase().includes(searchLower),
        )
      }

      // Sort by start time (upcoming first, then ongoing, then finished)
      filteredContests.sort((a, b) => {
        if (a.status !== b.status) {
          const statusOrder = { upcoming: 0, ongoing: 1, finished: 2 }
          return statusOrder[a.status] - statusOrder[b.status]
        }
        return new Date(a.startTime) - new Date(b.startTime)
      })

      // Add registration status for authenticated users
      const contestsWithRegistration = filteredContests.map((contest) => {
        let registrationStatus = "not-registered"
        if (req.user) {
          const registration = CONTEST_REGISTRATIONS.find((r) => r.contestId === contest.id && r.userId === req.user.id)
          if (registration) {
            registrationStatus = contest.status === "finished" ? "participated" : "registered"
          }
        }

        return {
          ...contest,
          registrationStatus,
        }
      })

      // Pagination
      const startIndex = (page - 1) * limit
      const endIndex = startIndex + Number.parseInt(limit)
      const paginatedContests = contestsWithRegistration.slice(startIndex, endIndex)

      res.json({
        contests: paginatedContests,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(contestsWithRegistration.length / limit),
          totalItems: contestsWithRegistration.length,
          itemsPerPage: Number.parseInt(limit),
        },
      })
    } catch (error) {
      console.error("Get contests error:", error)
      res.status(500).json({ error: "Failed to fetch contests" })
    }
  },
)

// Get contest by ID
router.get("/:id", [validateUUID("id"), handleValidationErrors], optionalAuth, (req, res) => {
  try {
    const contest = CONTESTS.find((c) => c.id === req.params.id)
    if (!contest) {
      return res.status(404).json({ error: "Contest not found" })
    }

    // Add registration status for authenticated users
    let registrationStatus = "not-registered"
    if (req.user) {
      const registration = CONTEST_REGISTRATIONS.find((r) => r.contestId === contest.id && r.userId === req.user.id)
      if (registration) {
        registrationStatus = contest.status === "finished" ? "participated" : "registered"
      }
    }

    res.json({
      contest: {
        ...contest,
        registrationStatus,
      },
    })
  } catch (error) {
    console.error("Get contest error:", error)
    res.status(500).json({ error: "Failed to fetch contest" })
  }
})

// Register for contest
router.post(
  "/:id/register",
  [
    authenticateToken,
    validateUUID("id"),
    body("isVirtual").optional().isBoolean().withMessage("isVirtual must be a boolean"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const contest = CONTESTS.find((c) => c.id === req.params.id)
      if (!contest) {
        return res.status(404).json({ error: "Contest not found" })
      }

      if (contest.status === "finished") {
        return res.status(400).json({ error: "Cannot register for finished contest" })
      }

      // Check if already registered
      const existingRegistration = CONTEST_REGISTRATIONS.find(
        (r) => r.contestId === req.params.id && r.userId === req.user.id,
      )

      if (existingRegistration) {
        return res.status(409).json({ error: "Already registered for this contest" })
      }

      const { isVirtual = false } = req.body

      // Create registration
      const registration = {
        id: generateId(),
        contestId: req.params.id,
        userId: req.user.id,
        registrationTime: new Date(),
        isVirtual,
      }

      CONTEST_REGISTRATIONS.push(registration)

      // Update participant count
      contest.participants += 1

      res.status(201).json({
        message: "Successfully registered for contest",
        registration,
      })
    } catch (error) {
      console.error("Register for contest error:", error)
      res.status(500).json({ error: "Failed to register for contest" })
    }
  },
)

// Unregister from contest
router.delete("/:id/register", [authenticateToken, validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const contest = CONTESTS.find((c) => c.id === req.params.id)
    if (!contest) {
      return res.status(404).json({ error: "Contest not found" })
    }

    if (contest.status === "ongoing" || contest.status === "finished") {
      return res.status(400).json({ error: "Cannot unregister from ongoing or finished contest" })
    }

    // Find and remove registration
    const registrationIndex = CONTEST_REGISTRATIONS.findIndex(
      (r) => r.contestId === req.params.id && r.userId === req.user.id,
    )

    if (registrationIndex === -1) {
      return res.status(404).json({ error: "Registration not found" })
    }

    CONTEST_REGISTRATIONS.splice(registrationIndex, 1)

    // Update participant count
    contest.participants -= 1

    res.json({ message: "Successfully unregistered from contest" })
  } catch (error) {
    console.error("Unregister from contest error:", error)
    res.status(500).json({ error: "Failed to unregister from contest" })
  }
})

// Create new contest
router.post(
  "/",
  [
    authenticateToken,
    body("title").trim().isLength({ min: 5, max: 200 }).withMessage("Title must be between 5 and 200 characters"),
    body("description")
      .trim()
      .isLength({ min: 10, max: 1000 })
      .withMessage("Description must be between 10 and 1000 characters"),
    body("startTime").isISO8601().withMessage("Start time must be a valid date"),
    body("endTime").isISO8601().withMessage("End time must be a valid date"),
    body("difficulty").isIn(["easy", "medium", "hard", "expert"]).withMessage("Invalid difficulty"),
    body("topics").isArray({ min: 1 }).withMessage("Must provide at least one topic"),
    body("eligibility")
      .optional()
      .trim()
      .isLength({ max: 200 })
      .withMessage("Eligibility must be less than 200 characters"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const {
        title,
        description,
        startTime,
        endTime,
        difficulty,
        topics,
        isVirtual = false,
        eligibility = "Open for all",
      } = req.body

      // Validate dates
      const start = new Date(startTime)
      const end = new Date(endTime)
      const now = new Date()

      if (start <= now) {
        return res.status(400).json({ error: "Start time must be in the future" })
      }

      if (end <= start) {
        return res.status(400).json({ error: "End time must be after start time" })
      }

      // Get organizer info
      const organizer = {
        id: req.user.id,
        name: req.user.name || "Unknown",
        avatar: req.user.avatar || "/placeholder.svg?height=40&width=40",
      }

      const newContest = {
        id: generateId(),
        title,
        description,
        startTime: start,
        endTime: end,
        status: "upcoming",
        organizer,
        difficulty,
        participants: 0,
        topics,
        isVirtual,
        eligibility,
        createdAt: new Date(),
        updatedAt: new Date(),
      }

      CONTESTS.push(newContest)

      res.status(201).json({
        message: "Contest created successfully",
        contest: newContest,
      })
    } catch (error) {
      console.error("Create contest error:", error)
      res.status(500).json({ error: "Failed to create contest" })
    }
  },
)

// Get user's contest registrations
router.get("/user/registrations", [authenticateToken, ...validatePagination, handleValidationErrors], (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query

    const userRegistrations = CONTEST_REGISTRATIONS.filter((r) => r.userId === req.user.id)

    // Get contest details for each registration
    const registrationsWithContests = userRegistrations
      .map((registration) => {
        const contest = CONTESTS.find((c) => c.id === registration.contestId)
        return {
          ...registration,
          contest,
        }
      })
      .filter((r) => r.contest) // Remove registrations for deleted contests

    // Sort by registration time (newest first)
    registrationsWithContests.sort((a, b) => new Date(b.registrationTime) - new Date(a.registrationTime))

    // Pagination
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + Number.parseInt(limit)
    const paginatedRegistrations = registrationsWithContests.slice(startIndex, endIndex)

    res.json({
      registrations: paginatedRegistrations,
      pagination: {
        currentPage: Number.parseInt(page),
        totalPages: Math.ceil(registrationsWithContests.length / limit),
        totalItems: registrationsWithContests.length,
        itemsPerPage: Number.parseInt(limit),
      },
    })
  } catch (error) {
    console.error("Get user registrations error:", error)
    res.status(500).json({ error: "Failed to fetch user registrations" })
  }
})

module.exports = router
