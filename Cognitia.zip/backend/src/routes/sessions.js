const express = require("express")
const { body, param, query } = require("express-validator")
const { handleValidationErrors, validateUUID, validatePagination } = require("../middleware/validation")
const { TASKS, generateId } = require("../data/mockData")

const router = express.Router()

// Mock study sessions data
const SESSIONS = [
  {
    id: generateId(),
    userId: "user_1",
    taskId: "task_1",
    startTime: new Date(Date.now() - 2 * 60 * 60 * 1000), // 2 hours ago
    endTime: new Date(Date.now() - 1 * 60 * 60 * 1000), // 1 hour ago
    duration: 60, // minutes
    goal: "Complete algorithm review",
    notes: "Reviewed sorting algorithms and their time complexities",
    createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
    updatedAt: new Date(Date.now() - 1 * 60 * 60 * 1000),
    completed: true,
  },
]

// Get all sessions for authenticated user
router.get(
  "/",
  [
    ...validatePagination,
    query("taskId").optional().isUUID().withMessage("Task ID must be a valid UUID"),
    query("dateFrom").optional().isISO8601().withMessage("Date from must be a valid date"),
    query("dateTo").optional().isISO8601().withMessage("Date to must be a valid date"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const { page = 1, limit = 10, taskId, dateFrom, dateTo } = req.query

      let userSessions = SESSIONS.filter((s) => s.userId === req.user.id)

      // Filter by task
      if (taskId) {
        userSessions = userSessions.filter((s) => s.taskId === taskId)
      }

      // Filter by date range
      if (dateFrom) {
        userSessions = userSessions.filter((s) => new Date(s.startTime) >= new Date(dateFrom))
      }

      if (dateTo) {
        userSessions = userSessions.filter((s) => new Date(s.startTime) <= new Date(dateTo))
      }

      // Sort by start time (newest first)
      userSessions.sort((a, b) => new Date(b.startTime) - new Date(a.startTime))

      // Add task details to sessions
      const sessionsWithTasks = userSessions.map((session) => {
        const task = TASKS.find((t) => t.id === session.taskId)
        return {
          ...session,
          task: task || null,
        }
      })

      // Pagination
      const startIndex = (page - 1) * limit
      const endIndex = startIndex + Number.parseInt(limit)
      const paginatedSessions = sessionsWithTasks.slice(startIndex, endIndex)

      res.json({
        sessions: paginatedSessions,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(sessionsWithTasks.length / limit),
          totalItems: sessionsWithTasks.length,
          itemsPerPage: Number.parseInt(limit),
        },
      })
    } catch (error) {
      console.error("Get sessions error:", error)
      res.status(500).json({ error: "Failed to fetch sessions" })
    }
  },
)

// Get session by ID
router.get("/:id", [validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const session = SESSIONS.find((s) => s.id === req.params.id && s.userId === req.user.id)
    if (!session) {
      return res.status(404).json({ error: "Session not found" })
    }

    // Add task details
    const task = TASKS.find((t) => t.id === session.taskId)
    const sessionWithTask = {
      ...session,
      task: task || null,
    }

    res.json({ session: sessionWithTask })
  } catch (error) {
    console.error("Get session error:", error)
    res.status(500).json({ error: "Failed to fetch session" })
  }
})

// Create new session
router.post(
  "/",
  [
    body("taskId").optional().isUUID().withMessage("Task ID must be a valid UUID"),
    body("startTime").isISO8601().withMessage("Start time must be a valid date"),
    body("endTime").optional().isISO8601().withMessage("End time must be a valid date"),
    body("goal").optional().trim().isLength({ max: 500 }).withMessage("Goal must be less than 500 characters"),
    body("notes").optional().trim().isLength({ max: 1000 }).withMessage("Notes must be less than 1000 characters"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const { taskId, startTime, endTime, goal, notes } = req.body

      // Validate task belongs to user if provided
      if (taskId) {
        const task = TASKS.find((t) => t.id === taskId && t.userId === req.user.id)
        if (!task) {
          return res.status(404).json({ error: "Task not found" })
        }
      }

      // Calculate duration if endTime is provided
      let duration = null
      let completed = false
      if (endTime) {
        const start = new Date(startTime)
        const end = new Date(endTime)
        if (end <= start) {
          return res.status(400).json({ error: "End time must be after start time" })
        }
        duration = Math.round((end - start) / (1000 * 60)) // minutes
        completed = true
      }

      const newSession = {
        id: generateId(),
        userId: req.user.id,
        taskId: taskId || null,
        startTime: new Date(startTime),
        endTime: endTime ? new Date(endTime) : null,
        duration,
        goal: goal || "",
        notes: notes || "",
        createdAt: new Date(),
        updatedAt: new Date(),
        completed,
      }

      SESSIONS.push(newSession)

      // Add task details to response
      const task = taskId ? TASKS.find((t) => t.id === taskId) : null
      const sessionWithTask = {
        ...newSession,
        task,
      }

      res.status(201).json({
        message: "Session created successfully",
        session: sessionWithTask,
      })
    } catch (error) {
      console.error("Create session error:", error)
      res.status(500).json({ error: "Failed to create session" })
    }
  },
)

// Update session
router.put(
  "/:id",
  [
    validateUUID("id"),
    body("taskId").optional().isUUID().withMessage("Task ID must be a valid UUID"),
    body("startTime").optional().isISO8601().withMessage("Start time must be a valid date"),
    body("endTime").optional().isISO8601().withMessage("End time must be a valid date"),
    body("goal").optional().trim().isLength({ max: 500 }).withMessage("Goal must be less than 500 characters"),
    body("notes").optional().trim().isLength({ max: 1000 }).withMessage("Notes must be less than 1000 characters"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const sessionIndex = SESSIONS.findIndex((s) => s.id === req.params.id && s.userId === req.user.id)
      if (sessionIndex === -1) {
        return res.status(404).json({ error: "Session not found" })
      }

      const session = SESSIONS[sessionIndex]
      const { taskId, startTime, endTime, goal, notes } = req.body

      // Validate task belongs to user if provided
      if (taskId) {
        const task = TASKS.find((t) => t.id === taskId && t.userId === req.user.id)
        if (!task) {
          return res.status(404).json({ error: "Task not found" })
        }
      }

      // Calculate duration if both times are provided
      let duration = session.duration
      let completed = session.completed

      const newStartTime = startTime ? new Date(startTime) : session.startTime
      const newEndTime = endTime ? new Date(endTime) : session.endTime

      if (newStartTime && newEndTime) {
        if (newEndTime <= newStartTime) {
          return res.status(400).json({ error: "End time must be after start time" })
        }
        duration = Math.round((newEndTime - newStartTime) / (1000 * 60)) // minutes
        completed = true
      }

      // Update session
      SESSIONS[sessionIndex] = {
        ...session,
        taskId: taskId !== undefined ? taskId : session.taskId,
        startTime: newStartTime,
        endTime: newEndTime,
        duration,
        goal: goal !== undefined ? goal : session.goal,
        notes: notes !== undefined ? notes : session.notes,
        completed,
        updatedAt: new Date(),
      }

      // Add task details to response
      const task = SESSIONS[sessionIndex].taskId ? TASKS.find((t) => t.id === SESSIONS[sessionIndex].taskId) : null
      const sessionWithTask = {
        ...SESSIONS[sessionIndex],
        task,
      }

      res.json({
        message: "Session updated successfully",
        session: sessionWithTask,
      })
    } catch (error) {
      console.error("Update session error:", error)
      res.status(500).json({ error: "Failed to update session" })
    }
  },
)

// End session
router.patch(
  "/:id/end",
  [
    validateUUID("id"),
    body("endTime").optional().isISO8601().withMessage("End time must be a valid date"),
    body("notes").optional().trim().isLength({ max: 1000 }).withMessage("Notes must be less than 1000 characters"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const session = SESSIONS.find((s) => s.id === req.params.id && s.userId === req.user.id)
      if (!session) {
        return res.status(404).json({ error: "Session not found" })
      }

      if (session.completed) {
        return res.status(400).json({ error: "Session is already completed" })
      }

      const { endTime, notes } = req.body
      const sessionEndTime = endTime ? new Date(endTime) : new Date()

      if (sessionEndTime <= session.startTime) {
        return res.status(400).json({ error: "End time must be after start time" })
      }

      // Calculate duration
      const duration = Math.round((sessionEndTime - session.startTime) / (1000 * 60)) // minutes

      // Update session
      session.endTime = sessionEndTime
      session.duration = duration
      session.completed = true
      session.updatedAt = new Date()

      if (notes !== undefined) {
        session.notes = notes
      }

      // Add task details to response
      const task = session.taskId ? TASKS.find((t) => t.id === session.taskId) : null
      const sessionWithTask = {
        ...session,
        task,
      }

      res.json({
        message: "Session ended successfully",
        session: sessionWithTask,
      })
    } catch (error) {
      console.error("End session error:", error)
      res.status(500).json({ error: "Failed to end session" })
    }
  },
)

// Delete session
router.delete("/:id", [validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const sessionIndex = SESSIONS.findIndex((s) => s.id === req.params.id && s.userId === req.user.id)
    if (sessionIndex === -1) {
      return res.status(404).json({ error: "Session not found" })
    }

    // Remove session
    SESSIONS.splice(sessionIndex, 1)

    res.json({ message: "Session deleted successfully" })
  } catch (error) {
    console.error("Delete session error:", error)
    res.status(500).json({ error: "Failed to delete session" })
  }
})

// Get session statistics
router.get("/stats/overview", (req, res) => {
  try {
    const userSessions = SESSIONS.filter((s) => s.userId === req.user.id && s.completed)

    const totalSessions = userSessions.length
    const totalMinutes = userSessions.reduce((sum, session) => sum + (session.duration || 0), 0)
    const totalHours = Math.round((totalMinutes / 60) * 10) / 10

    // Calculate average session length
    const avgSessionLength = totalSessions > 0 ? Math.round((totalMinutes / totalSessions) * 10) / 10 : 0

    // Get sessions from last 7 days
    const sevenDaysAgo = new Date()
    sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7)

    const recentSessions = userSessions.filter((s) => new Date(s.startTime) >= sevenDaysAgo)

    const recentMinutes = recentSessions.reduce((sum, session) => sum + (session.duration || 0), 0)
    const recentHours = Math.round((recentMinutes / 60) * 10) / 10

    const stats = {
      totalSessions,
      totalHours,
      totalMinutes,
      avgSessionLength,
      recentSessions: recentSessions.length,
      recentHours,
      longestSession: totalSessions > 0 ? Math.max(...userSessions.map((s) => s.duration || 0)) : 0,
    }

    res.json({ stats })
  } catch (error) {
    console.error("Get session stats error:", error)
    res.status(500).json({ error: "Failed to fetch session statistics" })
  }
})

module.exports = router
