const express = require("express")
const { body, param, query } = require("express-validator")
const { handleValidationErrors, validateUUID, validatePagination } = require("../middleware/validation")
const { generateId } = require("../data/mockData")

const router = express.Router()

// Mock model test data
const MODEL_TESTS = [
  {
    id: generateId(),
    title: "Mathematics Comprehensive Test",
    description: "A comprehensive test covering various topics in mathematics",
    timeLimit: 60,
    subjects: ["Mathematics"],
    topics: ["Algebra", "Geometry", "Calculus", "Trigonometry", "Statistics"],
    difficulty: "medium",
    questions: [],
    isCustom: false,
    passingScore: 60,
    totalPoints: 200,
    createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
  },
  {
    id: generateId(),
    title: "Physics Fundamentals",
    description: "Test your knowledge of fundamental physics concepts",
    timeLimit: 45,
    subjects: ["Physics"],
    topics: ["Mechanics", "Thermodynamics", "Electromagnetism", "Optics"],
    difficulty: "easy",
    questions: [],
    isCustom: false,
    passingScore: 50,
    totalPoints: 100,
    createdAt: new Date(Date.now() - 20 * 24 * 60 * 60 * 1000),
  },
]

const TEST_ATTEMPTS = []

// Get all model tests
router.get(
  "/",
  [
    ...validatePagination,
    query("difficulty").optional().isIn(["all", "easy", "medium", "hard", "expert"]).withMessage("Invalid difficulty"),
    query("subject").optional().isString().withMessage("Subject must be a string"),
    query("search").optional().isString().withMessage("Search must be a string"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const { page = 1, limit = 10, difficulty = "all", subject, search } = req.query

      let filteredTests = [...MODEL_TESTS]

      // Filter by difficulty
      if (difficulty !== "all") {
        filteredTests = filteredTests.filter((t) => t.difficulty === difficulty)
      }

      // Filter by subject
      if (subject) {
        filteredTests = filteredTests.filter((t) => t.subjects.includes(subject))
      }

      // Filter by search term
      if (search) {
        const searchLower = search.toLowerCase()
        filteredTests = filteredTests.filter(
          (t) => t.title.toLowerCase().includes(searchLower) || t.description.toLowerCase().includes(searchLower),
        )
      }

      // Sort by creation date (newest first)
      filteredTests.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))

      // Add attempt status for user
      const testsWithAttempts = filteredTests.map((test) => {
        const userAttempts = TEST_ATTEMPTS.filter((a) => a.testId === test.id && a.userId === req.user.id)

        const lastAttempt =
          userAttempts.length > 0 ? userAttempts.sort((a, b) => new Date(b.startTime) - new Date(a.startTime))[0] : null

        return {
          ...test,
          attemptCount: userAttempts.length,
          lastAttempt,
          hasInProgressAttempt: userAttempts.some((a) => a.status === "in-progress"),
        }
      })

      // Pagination
      const startIndex = (page - 1) * limit
      const endIndex = startIndex + Number.parseInt(limit)
      const paginatedTests = testsWithAttempts.slice(startIndex, endIndex)

      res.json({
        tests: paginatedTests,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(testsWithAttempts.length / limit),
          totalItems: testsWithAttempts.length,
          itemsPerPage: Number.parseInt(limit),
        },
      })
    } catch (error) {
      console.error("Get model tests error:", error)
      res.status(500).json({ error: "Failed to fetch model tests" })
    }
  },
)

// Get test by ID
router.get("/:id", [validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const test = MODEL_TESTS.find((t) => t.id === req.params.id)
    if (!test) {
      return res.status(404).json({ error: "Test not found" })
    }

    // Get user's attempts for this test
    const userAttempts = TEST_ATTEMPTS.filter((a) => a.testId === test.id && a.userId === req.user.id)

    const lastAttempt =
      userAttempts.length > 0 ? userAttempts.sort((a, b) => new Date(b.startTime) - new Date(a.startTime))[0] : null

    res.json({
      test: {
        ...test,
        attemptCount: userAttempts.length,
        lastAttempt,
        hasInProgressAttempt: userAttempts.some((a) => a.status === "in-progress"),
      },
    })
  } catch (error) {
    console.error("Get test error:", error)
    res.status(500).json({ error: "Failed to fetch test" })
  }
})

// Start test attempt
router.post("/:id/start", [validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const test = MODEL_TESTS.find((t) => t.id === req.params.id)
    if (!test) {
      return res.status(404).json({ error: "Test not found" })
    }

    // Check if user has an in-progress attempt
    const inProgressAttempt = TEST_ATTEMPTS.find(
      (a) => a.testId === test.id && a.userId === req.user.id && a.status === "in-progress",
    )

    if (inProgressAttempt) {
      return res.json({
        message: "Resuming existing attempt",
        attempt: inProgressAttempt,
      })
    }

    // Create new attempt
    const newAttempt = {
      id: generateId(),
      userId: req.user.id,
      testId: test.id,
      status: "in-progress",
      startTime: new Date(),
      totalQuestions: test.questions.length || 10, // Default for demo
      answers: {},
      createdAt: new Date(),
      updatedAt: new Date(),
    }

    TEST_ATTEMPTS.push(newAttempt)

    res.status(201).json({
      message: "Test attempt started",
      attempt: newAttempt,
    })
  } catch (error) {
    console.error("Start test error:", error)
    res.status(500).json({ error: "Failed to start test" })
  }
})

// Submit answer
router.post(
  "/attempts/:attemptId/answer",
  [
    validateUUID("attemptId"),
    body("questionId").isUUID().withMessage("Question ID must be a valid UUID"),
    body("answer").isInt({ min: 0, max: 3 }).withMessage("Answer must be between 0 and 3"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const attempt = TEST_ATTEMPTS.find((a) => a.id === req.params.attemptId && a.userId === req.user.id)

      if (!attempt) {
        return res.status(404).json({ error: "Test attempt not found" })
      }

      if (attempt.status !== "in-progress") {
        return res.status(400).json({ error: "Test attempt is not in progress" })
      }

      const { questionId, answer } = req.body

      // Save answer
      attempt.answers[questionId] = answer
      attempt.updatedAt = new Date()

      res.json({
        message: "Answer submitted successfully",
        answeredQuestions: Object.keys(attempt.answers).length,
        totalQuestions: attempt.totalQuestions,
      })
    } catch (error) {
      console.error("Submit answer error:", error)
      res.status(500).json({ error: "Failed to submit answer" })
    }
  },
)

// Finish test
router.post("/attempts/:attemptId/finish", [validateUUID("attemptId"), handleValidationErrors], (req, res) => {
  try {
    const attempt = TEST_ATTEMPTS.find((a) => a.id === req.params.attemptId && a.userId === req.user.id)

    if (!attempt) {
      return res.status(404).json({ error: "Test attempt not found" })
    }

    if (attempt.status !== "in-progress") {
      return res.status(400).json({ error: "Test attempt is not in progress" })
    }

    const test = MODEL_TESTS.find((t) => t.id === attempt.testId)
    if (!test) {
      return res.status(404).json({ error: "Test not found" })
    }

    // Calculate score (simplified - in real app, check against correct answers)
    const answeredQuestions = Object.keys(attempt.answers).length
    const score = Math.floor(Math.random() * test.totalPoints) // Random score for demo
    const correctAnswers = Math.floor(Math.random() * answeredQuestions)

    // Update attempt
    attempt.status = "completed"
    attempt.endTime = new Date()
    attempt.timeSpent = Math.floor((attempt.endTime - attempt.startTime) / 1000)
    attempt.score = score
    attempt.correctAnswers = correctAnswers
    attempt.updatedAt = new Date()

    res.json({
      message: "Test completed successfully",
      attempt,
      passed: score >= test.passingScore,
    })
  } catch (error) {
    console.error("Finish test error:", error)
    res.status(500).json({ error: "Failed to finish test" })
  }
})

// Get test results
router.get("/attempts/:attemptId/results", [validateUUID("attemptId"), handleValidationErrors], (req, res) => {
  try {
    const attempt = TEST_ATTEMPTS.find((a) => a.id === req.params.attemptId && a.userId === req.user.id)

    if (!attempt) {
      return res.status(404).json({ error: "Test attempt not found" })
    }

    if (attempt.status !== "completed") {
      return res.status(400).json({ error: "Test attempt is not completed" })
    }

    const test = MODEL_TESTS.find((t) => t.id === attempt.testId)
    if (!test) {
      return res.status(404).json({ error: "Test not found" })
    }

    const passed = attempt.score >= test.passingScore
    const percentage = Math.round((attempt.score / test.totalPoints) * 100)

    res.json({
      attempt,
      test,
      passed,
      percentage,
      results: {
        score: attempt.score,
        totalPoints: test.totalPoints,
        correctAnswers: attempt.correctAnswers,
        totalQuestions: attempt.totalQuestions,
        timeSpent: attempt.timeSpent,
        passingScore: test.passingScore,
      },
    })
  } catch (error) {
    console.error("Get test results error:", error)
    res.status(500).json({ error: "Failed to fetch test results" })
  }
})

// Get user's test history
router.get("/user/history", [...validatePagination, handleValidationErrors], (req, res) => {
  try {
    const { page = 1, limit = 10 } = req.query

    const userAttempts = TEST_ATTEMPTS.filter((a) => a.userId === req.user.id)

    // Add test details to attempts
    const attemptsWithTests = userAttempts
      .map((attempt) => {
        const test = MODEL_TESTS.find((t) => t.id === attempt.testId)
        return {
          ...attempt,
          test,
        }
      })
      .filter((a) => a.test) // Remove attempts for deleted tests

    // Sort by start time (newest first)
    attemptsWithTests.sort((a, b) => new Date(b.startTime) - new Date(a.startTime))

    // Pagination
    const startIndex = (page - 1) * limit
    const endIndex = startIndex + Number.parseInt(limit)
    const paginatedAttempts = attemptsWithTests.slice(startIndex, endIndex)

    res.json({
      attempts: paginatedAttempts,
      pagination: {
        currentPage: Number.parseInt(page),
        totalPages: Math.ceil(attemptsWithTests.length / limit),
        totalItems: attemptsWithTests.length,
        itemsPerPage: Number.parseInt(limit),
      },
    })
  } catch (error) {
    console.error("Get test history error:", error)
    res.status(500).json({ error: "Failed to fetch test history" })
  }
})

// Create custom test
router.post(
  "/custom",
  [
    body("title").trim().isLength({ min: 5, max: 200 }).withMessage("Title must be between 5 and 200 characters"),
    body("description")
      .trim()
      .isLength({ min: 10, max: 1000 })
      .withMessage("Description must be between 10 and 1000 characters"),
    body("timeLimit").isInt({ min: 5, max: 300 }).withMessage("Time limit must be between 5 and 300 minutes"),
    body("subjects").isArray({ min: 1 }).withMessage("Must provide at least one subject"),
    body("topics").isArray({ min: 1 }).withMessage("Must provide at least one topic"),
    body("difficulty").isIn(["easy", "medium", "hard", "expert"]).withMessage("Invalid difficulty"),
    body("questionCount").isInt({ min: 5, max: 50 }).withMessage("Question count must be between 5 and 50"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const { title, description, timeLimit, subjects, topics, difficulty, questionCount } = req.body

      const difficultyPoints = {
        easy: 5,
        medium: 10,
        hard: 15,
        expert: 20,
      }

      const totalPoints = questionCount * difficultyPoints[difficulty]
      const passingScore = Math.floor(totalPoints * 0.6) // 60% passing score

      const newTest = {
        id: generateId(),
        title,
        description,
        timeLimit,
        subjects,
        topics,
        difficulty,
        questions: [], // In real app, generate questions based on topics
        isCustom: true,
        passingScore,
        totalPoints,
        createdAt: new Date(),
        createdBy: req.user.id,
      }

      MODEL_TESTS.push(newTest)

      res.status(201).json({
        message: "Custom test created successfully",
        test: newTest,
      })
    } catch (error) {
      console.error("Create custom test error:", error)
      res.status(500).json({ error: "Failed to create custom test" })
    }
  },
)

module.exports = router
