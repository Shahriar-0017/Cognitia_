const express = require("express")
const { body, param, query } = require("express-validator")
const { authenticateToken, optionalAuth } = require("../middleware/auth")
const {
  handleValidationErrors,
  validateQuestion,
  validateUUID,
  validatePagination,
} = require("../middleware/validation")
const { QUESTIONS, ANSWERS, USERS, generateId, CURRENT_USER } = require("../data/mockData")

const router = express.Router()

// Get all questions with pagination and filtering
router.get(
  "/",
  [
    ...validatePagination,
    query("tags").optional().isString().withMessage("Tags must be a string"),
    query("search").optional().isString().withMessage("Search must be a string"),
    query("status").optional().isIn(["all", "resolved", "unresolved"]).withMessage("Invalid status"),
    query("sortBy")
      .optional()
      .isIn(["newest", "oldest", "most_viewed", "most_voted"])
      .withMessage("Invalid sort option"),
    handleValidationErrors,
  ],
  optionalAuth,
  (req, res) => {
    try {
      const { page = 1, limit = 10, tags, search, status = "all", sortBy = "newest" } = req.query

      let filteredQuestions = [...QUESTIONS]

      // Filter by tags
      if (tags) {
        const tagArray = tags.split(",").map((tag) => tag.trim())
        filteredQuestions = filteredQuestions.filter((q) => tagArray.some((tag) => q.tags.includes(tag)))
      }

      // Filter by search term
      if (search) {
        const searchLower = search.toLowerCase()
        filteredQuestions = filteredQuestions.filter(
          (q) => q.title.toLowerCase().includes(searchLower) || q.body.toLowerCase().includes(searchLower),
        )
      }

      // Filter by status
      if (status === "resolved") {
        filteredQuestions = filteredQuestions.filter((q) => q.isResolved)
      } else if (status === "unresolved") {
        filteredQuestions = filteredQuestions.filter((q) => !q.isResolved)
      }

      // Sort questions
      switch (sortBy) {
        case "oldest":
          filteredQuestions.sort((a, b) => new Date(a.createdAt) - new Date(b.createdAt))
          break
        case "most_viewed":
          filteredQuestions.sort((a, b) => b.views - a.views)
          break
        case "most_voted":
          filteredQuestions.sort((a, b) => b.voteCount - a.voteCount)
          break
        case "newest":
        default:
          filteredQuestions.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
          break
      }

      // Pagination
      const startIndex = (page - 1) * limit
      const endIndex = startIndex + Number.parseInt(limit)
      const paginatedQuestions = filteredQuestions.slice(startIndex, endIndex)

      // Add answer count to each question
      const questionsWithAnswerCount = paginatedQuestions.map((question) => ({
        ...question,
        answerCount: ANSWERS.filter((a) => a.questionId === question.id).length,
      }))

      res.json({
        questions: questionsWithAnswerCount,
        pagination: {
          currentPage: Number.parseInt(page),
          totalPages: Math.ceil(filteredQuestions.length / limit),
          totalItems: filteredQuestions.length,
          itemsPerPage: Number.parseInt(limit),
        },
      })
    } catch (error) {
      console.error("Get questions error:", error)
      res.status(500).json({ error: "Failed to fetch questions" })
    }
  },
)

// Get question by ID
router.get("/:id", [validateUUID("id"), handleValidationErrors], optionalAuth, (req, res) => {
  try {
    const question = QUESTIONS.find((q) => q.id === req.params.id)
    if (!question) {
      return res.status(404).json({ error: "Question not found" })
    }

    // Increment view count (in real app, you might want to track unique views)
    question.views += 1

    // Get answers for this question
    const answers = ANSWERS.filter((a) => a.questionId === question.id)

    res.json({
      question: {
        ...question,
        answerCount: answers.length,
      },
      answers,
    })
  } catch (error) {
    console.error("Get question error:", error)
    res.status(500).json({ error: "Failed to fetch question" })
  }
})

// Create new question
router.post("/", [authenticateToken, ...validateQuestion, handleValidationErrors], (req, res) => {
  try {
    const { title, body, tags } = req.body
    const author = USERS.find((u) => u.id === req.user.id)

    if (!author) {
      return res.status(404).json({ error: "User not found" })
    }

    const newQuestion = {
      id: generateId(),
      title,
      body,
      authorId: req.user.id,
      author,
      tags,
      views: 0,
      isResolved: false,
      createdAt: new Date(),
      updatedAt: new Date(),
      voteCount: 0,
    }

    QUESTIONS.push(newQuestion)

    res.status(201).json({
      message: "Question created successfully",
      question: {
        ...newQuestion,
        answerCount: 0,
      },
    })
  } catch (error) {
    console.error("Create question error:", error)
    res.status(500).json({ error: "Failed to create question" })
  }
})

// Update question
router.put("/:id", [authenticateToken, validateUUID("id"), ...validateQuestion, handleValidationErrors], (req, res) => {
  try {
    const questionIndex = QUESTIONS.findIndex((q) => q.id === req.params.id)
    if (questionIndex === -1) {
      return res.status(404).json({ error: "Question not found" })
    }

    const question = QUESTIONS[questionIndex]

    // Check if user owns the question
    if (question.authorId !== req.user.id) {
      return res.status(403).json({ error: "Not authorized to update this question" })
    }

    const { title, body, tags } = req.body

    // Update question
    QUESTIONS[questionIndex] = {
      ...question,
      title,
      body,
      tags,
      updatedAt: new Date(),
    }

    res.json({
      message: "Question updated successfully",
      question: QUESTIONS[questionIndex],
    })
  } catch (error) {
    console.error("Update question error:", error)
    res.status(500).json({ error: "Failed to update question" })
  }
})

// Delete question
router.delete("/:id", [authenticateToken, validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const questionIndex = QUESTIONS.findIndex((q) => q.id === req.params.id)
    if (questionIndex === -1) {
      return res.status(404).json({ error: "Question not found" })
    }

    const question = QUESTIONS[questionIndex]

    // Check if user owns the question or is admin
    if (question.authorId !== req.user.id && req.user.role !== "admin") {
      return res.status(403).json({ error: "Not authorized to delete this question" })
    }

    // Remove question
    QUESTIONS.splice(questionIndex, 1)

    // Remove associated answers
    const answerIndices = []
    ANSWERS.forEach((answer, index) => {
      if (answer.questionId === req.params.id) {
        answerIndices.push(index)
      }
    })

    // Remove answers in reverse order to maintain indices
    answerIndices.reverse().forEach((index) => {
      ANSWERS.splice(index, 1)
    })

    res.json({ message: "Question deleted successfully" })
  } catch (error) {
    console.error("Delete question error:", error)
    res.status(500).json({ error: "Failed to delete question" })
  }
})

// Vote on question
router.post(
  "/:id/vote",
  [
    authenticateToken,
    validateUUID("id"),
    body("voteType").isIn(["up", "down"]).withMessage("Vote type must be up or down"),
    handleValidationErrors,
  ],
  (req, res) => {
    try {
      const question = QUESTIONS.find((q) => q.id === req.params.id)
      if (!question) {
        return res.status(404).json({ error: "Question not found" })
      }

      const { voteType } = req.body

      // In a real app, you'd track individual votes in a separate table
      // For demo purposes, we'll just update the vote count
      if (voteType === "up") {
        question.voteCount += 1
      } else {
        question.voteCount -= 1
      }

      res.json({
        message: "Vote recorded successfully",
        voteCount: question.voteCount,
      })
    } catch (error) {
      console.error("Vote question error:", error)
      res.status(500).json({ error: "Failed to record vote" })
    }
  },
)

// Mark question as resolved
router.patch("/:id/resolve", [authenticateToken, validateUUID("id"), handleValidationErrors], (req, res) => {
  try {
    const question = QUESTIONS.find((q) => q.id === req.params.id)
    if (!question) {
      return res.status(404).json({ error: "Question not found" })
    }

    // Check if user owns the question
    if (question.authorId !== req.user.id) {
      return res.status(403).json({ error: "Not authorized to resolve this question" })
    }

    question.isResolved = true
    question.updatedAt = new Date()

    res.json({
      message: "Question marked as resolved",
      question,
    })
  } catch (error) {
    console.error("Resolve question error:", error)
    res.status(500).json({ error: "Failed to resolve question" })
  }
})

module.exports = router
