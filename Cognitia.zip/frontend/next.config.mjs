/** @type {import('next').NextConfig} */
const nextConfig = {
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    unoptimized: true,
  },
  distDir: '.next',
  pageExtensions: ['js', 'ts', 'jsx', 'tsx', 'mdx'],
}

export default nextConfig
